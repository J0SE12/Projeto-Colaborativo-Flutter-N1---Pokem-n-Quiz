class Pokemon {
  final String imgUrl;
  final String name;

  Pokemon(this.name, this.imgUrl);
}